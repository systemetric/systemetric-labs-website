from sr.robot import *

from time import sleep

__version__ = 0.2

class TestRobot(Robot):
    def __init__(self):
        super(TestRobot, self).__init__(init=False)
        self.init()
        print "Robot initialised, waiting for start..."
        self.wait_start()
        while True:
            print "I can see these markers:"
            print ", ".join([m.info.code for m in self.see()])
            sleep(2)

if __name__ == "__main__":
    TestRobot()
